setTimeout(function () {
    window.location.href = "tool.html"
}, 1);